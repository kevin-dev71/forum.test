<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <h1 class="text-center text-muted"><?php echo e(__("Respuestas al debate :name", ['name' => $post->title])); ?></h1>

            <h4><?php echo e(__("Autor del debate")); ?>: <?php echo e($post->owner->name); ?></h4>

            <a href="/forums/<?php echo e($post->forum->slug); ?>" class="btn btn-info pull-right">
                <?php echo e(__("Volver al foro :name", ['name' => $post->forum->name])); ?>

            </a>

            <div class="clearfix"></div>

            <br />

            <?php $__empty_1 = true; $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="panel panel-default">
                    <div class="panel-heading panel-heading-reply">
                        <p><?php echo e(__("Respuesta de")); ?>: <?php echo e($reply->author->name); ?></p>
                    </div>

                    <div class="panel-body">
                        <?php echo e($reply->reply); ?>


                        <?php if($reply->attachment): ?>
                            <img src="<?php echo e($reply->pathAttachment()); ?>" class="img-responsive img-rounded"/>
                        <?php endif; ?>
                    </div>

                    <?php if($reply->isAuthor()): ?>
                        <div class="panel-footer">
                            <form method="POST" action="<?php echo e(route('replies.delete', [$reply->id])); ?>">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button type="submit" name="deleteReply" class="btn btn-danger">
                                    <?php echo e(__("Eliminar respuesta")); ?>

                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    <?php echo e(__("No hay ninguna respuesta en este momento")); ?>

                </div>
            <?php endif; ?>

            <?php if($replies->count()): ?>
                <?php echo e($replies->links()); ?>

            <?php endif; ?>

            <?php if (\Illuminate\Support\Facades\Blade::check('Logged')): ?>
                <h3 class="text-muted"><?php echo e(__("Añadir una nueva respuesta al post :name", ['name' => $post->name])); ?></h3>
                <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
                <form method="POST" action="/replies" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>" />
                    
                    <div class="form-group">
                        <label for="reply" class="col-md-12 control-label"><?php echo e(__("Respuesta")); ?></label>
                        <textarea id="reply" class="form-control" name="reply"><?php echo e(old('reply')); ?></textarea>
                    </div>

                    <label class="btn btn-warning" for="file">
                        <input id="file" name="file" type="file" style="display:none;">
                        <?php echo e(__("Añadir archivo")); ?>

                    </label>
                    
                    <button type="submit" name="addReply" class="btn btn-default"><?php echo e(__("Añadir respuesta")); ?></button>
                </form>
            <?php else: ?>
                <?php echo $__env->make('partials.login_link', ['message' => __("Inicia sessión para responder")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>