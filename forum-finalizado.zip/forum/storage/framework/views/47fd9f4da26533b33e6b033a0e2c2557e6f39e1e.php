<div class="text-center">
    <a href="/login"><?php echo e($message); ?></a>
</div>