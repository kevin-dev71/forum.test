<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <h1 class="text-center text-muted">
                <?php echo e(__("Posts del foro :name", ['name' => $forum->name])); ?>

            </h1>

            <a href="/" class="btn btn-info pull-right">
                <?php echo e(__("Volver al listado de los foros")); ?>

            </a>

            <div class="clearfix"></div>

            <br/>

            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="panel panel-default">
                    <div class="panel-heading panel-heading-post">
                        <a href="/posts/<?php echo e($post->slug); ?>"><?php echo e($post->title); ?></a>
                        <span class="pull-right">
                            <?php echo e(__("Owner")); ?>: <?php echo e($post->owner->name); ?>

                        </span>
                    </div>

                    <div class="panel-body">
                        <?php echo e($post->description); ?>


                        <hr />

                        <b><?php echo e($post->showCategories($post->categories, __("Categorías"))); ?><br /></b>

                        <?php if($post->attachment): ?>
                            <img src="<?php echo e($post->pathAttachment()); ?>" class="img-responsive img-rounded"/>
                        <?php endif; ?>
                    </div>

                    <?php if($post->isOwner()): ?>
                        <div class="panel-footer">
                            <form method="POST" action="/posts/<?php echo e($post->slug); ?>">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button type="submit" name="deletePost" class="btn btn-danger">
                                    <?php echo e(__("Eliminar post")); ?>

                                </button>
                            </form>
                        </div>
                    <?php endif; ?>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-danger">
                    <?php echo e(__("No hay ningún post en este momento")); ?>

                </div>
            <?php endif; ?>

            <?php if($posts->count()): ?>
                <?php echo e($posts->links()); ?>

            <?php endif; ?>

            <?php if (\Illuminate\Support\Facades\Blade::check('Logged')): ?>
            <h3 class="text-muted"><?php echo e(__("Añadir un nuevo post al foro :name", ['name' => $forum->name])); ?></h3>
            <?php echo $__env->make('partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form method="POST" action="/posts" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="forum_id" value="<?php echo e($forum->id); ?>"/>

                <div class="form-group">
                    <label for="title" class="col-md-12 control-label"><?php echo e(__("Título")); ?></label>
                    <input id="title" class="form-control" name="title" value="<?php echo e(old('title')); ?>"/>
                </div>

                <div class="form-group">
                    <label for="description" class="col-md-12 control-label"><?php echo e(__("Descripción")); ?></label>
                    <textarea id="description" class="form-control"
                              name="description"><?php echo e(old('description')); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="categories"><?php echo e(__("Categorías")); ?></label>
                    <select multiple class="form-control" id="categories" name="categories[]" size="11">
                        <option value=""><?php echo e(__("Selecciona categorías")); ?></option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <label class="btn btn-warning" for="file">
                    <input id="file" name="file" type="file" style="display:none;">
                    <?php echo e(__("Subir archivo")); ?>

                </label>

                <button type="submit" name="addPost" class="btn btn-default"><?php echo e(__("Añadir post")); ?></button>
            </form>
            <?php else: ?>
                <?php echo $__env->make('partials.login_link', ['message' => __("Inicia sesión para crear un post")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>