<form method="POST" action="/forums/search">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-xs-12">
            <div class="input-group input-group-lg">
                <input type="text" name="search" value="<?php echo e(session('search')); ?>" class="form-control" />
                <div class="input-group-btn">
                    <button type="submit" class="btn btn-primary"><?php echo e(__("Buscar")); ?></button>
                    <a href="<?php echo e(route('forums.clear_search')); ?>" class="btn btn-default">
                        <?php echo e(__("Limpiar")); ?>

                    </a>
                </div>
            </div>
        </div>
    </div>
</form>