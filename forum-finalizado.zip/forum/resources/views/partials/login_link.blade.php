<div class="text-center">
    <a href="/login">{{ $message }}</a>
</div>